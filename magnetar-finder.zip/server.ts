import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Server-side Gemini AI client initialization
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      aiClient = new GoogleGenAI({ apiKey });
    }
  }
  return aiClient;
}

// Health API
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Astrophysics AI Analysis Endpoint
app.post("/api/analyze", async (req, res) => {
  try {
    const { targetGroup, eventId, context, query } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        hypothesis: "Gemini API key not configured in environment. Displaying local heuristic simulation model.",
        anomalyScore: "0.942",
        recommendedActions: [
          "Verify X-ray telemetry flux with RXTE archives.",
          "Check magnetosphere reconnection threshold."
        ],
        theoreticalPhysicsModel: "Relativistic Twisted Magnetosphere Model (Thompson & Duncan 1995)"
      });
    }

    const prompt = `You are Magnetar Finder's senior astrophysics AI system. 
Analyze the following magnetar observation anomaly and provide concise scientific findings.

Target Group / Source: ${targetGroup || 'Unknown Sector'}
Event ID: ${eventId || 'EVT-ANOMALY-99'}
Context: ${context || 'Observed high energy burst and spectral line shift.'}
User Query: ${query || 'Identify physical mechanisms and spectral classification.'}

Format response as JSON with fields:
- hypothesis: string
- anomalyScore: string (e.g. "0.985")
- recommendedActions: string array
- theoreticalPhysicsModel: string
- magneticFieldEstimate: string`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const resultText = response.text || "{}";
    const parsed = JSON.parse(resultText);
    res.json(parsed);
  } catch (error: any) {
    console.error("Gemini analysis error:", error);
    res.status(500).json({ error: error.message || "Analysis failed" });
  }
});

async function startServer() {
  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Magnetar Finder Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
