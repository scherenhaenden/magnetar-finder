export type NavigationTab = 'exploration' | 'analysis' | 'archives' | 'database' | 'protocols';

export interface DatabaseSource {
  id: string;
  name: string;
  size: string;
  records: string;
  lastSync: string;
  status: 'active' | 'offline';
  path?: string;
  connected: boolean;
}

export interface SavedFinding {
  id: string;
  eventId: string;
  type: 'Gamma Flare' | 'X-Ray Burst' | 'Glitch' | 'Quiescent';
  magnitude: string;
  customNote: string;
  refLink?: string;
  bookmarked: boolean;
}

export interface AntecedentData {
  eventId: string;
  precursorEnergyErgs: string;
  orbitalPhase: string;
  telemetryStation: string;
  harmonicFrequenciesHz: number[];
  waveformPoints: number[];
}

export interface QueryResult {
  id: string;
  statusLight: 'active' | 'dim';
  sourceDb: string;
  timestamp: string;
  previewContent: string;
  antecedents: AntecedentData;
  saved?: boolean;
}

export interface TimelineEvent {
  id: string;
  time: string;
  title: string;
  description: string;
  nodeType: 'highlight' | 'warning' | 'normal';
}

export interface UniqueGroup {
  id: string;
  value: string;
  count: number;
  peakDailyRate: string;
  distributionBars: number[]; // 12 values 0-100
  timelineEvents: TimelineEvent[];
}

export interface ProtocolItem {
  id: string;
  name: string;
  category: string;
  description: string;
  status: 'IDLE' | 'RUNNING' | 'COMPLETED' | 'ERROR';
  lastRun: string;
  executionTimeMs: number;
}

export interface ArchiveFile {
  id: string;
  name: string;
  size: string;
  date: string;
  telescope: string;
  downloads: number;
}

export interface AngularComponentCode {
  title: string;
  selector: string;
  tsCode: string;
  htmlCode: string;
}
