import {
  DatabaseSource,
  SavedFinding,
  QueryResult,
  UniqueGroup,
  ProtocolItem,
  ArchiveFile,
  AngularComponentCode
} from '../types';

export const INITIAL_DATABASES: DatabaseSource[] = [
  {
    id: 'db-1',
    name: 'SGR_1806_20.sqlite',
    size: '4.2 GB',
    records: '1,402,883',
    lastSync: '10m ago',
    status: 'active',
    connected: true
  },
  {
    id: 'db-2',
    name: 'AXP_1E_1048.sqlite',
    size: '1.8 GB',
    records: '890,210',
    lastSync: '1h ago',
    status: 'active',
    connected: true
  },
  {
    id: 'db-3',
    name: 'Historical_XRay.db',
    size: '12.4 GB',
    records: '4,892,100',
    lastSync: 'Offline Archive',
    status: 'offline',
    path: '/mnt/archive/hxr/',
    connected: false
  }
];

export const INITIAL_SAVED_FINDINGS: SavedFinding[] = [
  {
    id: 'find-1',
    eventId: 'EVT-992-A',
    type: 'Gamma Flare',
    magnitude: '10^46 erg',
    customNote: 'Anomalous spike duration. Requires cross-check with RXTE data.',
    refLink: 'https://arxiv.org/abs/2310.992a',
    bookmarked: true
  },
  {
    id: 'find-2',
    eventId: 'EVT-992-B',
    type: 'X-Ray Burst',
    magnitude: '10^41 erg',
    customNote: 'Secondary emission trailing main flare. Typical decay profile.',
    bookmarked: false
  },
  {
    id: 'find-3',
    eventId: 'EVT-104-X',
    type: 'Glitch',
    magnitude: 'Δν/ν ~ 10^-6',
    customNote: 'Sudden spin-up event. Possible crustal fracture.',
    refLink: 'https://simbad.u-strasbg.fr/evt104x',
    bookmarked: true
  },
  {
    id: 'find-4',
    eventId: 'EVT-211-Q',
    type: 'Quiescent',
    magnitude: '--',
    customNote: 'Baseline measurement for normalization.',
    bookmarked: false
  }
];

export const INITIAL_QUERY_RESULTS: QueryResult[] = [
  {
    id: 'qr-1',
    statusLight: 'active',
    sourceDb: 'MGT_SGR_1806_20',
    timestamp: '2023-10-12 04:22:19',
    previewContent: 'Detection of intense gamma ray burst correlating with magnetic anomaly in sector 4...',
    antecedents: {
      eventId: 'EVT-992-A',
      precursorEnergyErgs: '3.4 × 10^45',
      orbitalPhase: '0.842 π rad',
      telemetryStation: 'Orbital Array Station 4',
      harmonicFrequenciesHz: [24.5, 48.2, 96.4, 192.8],
      waveformPoints: [10, 22, 45, 88, 120, 95, 60, 30, 85, 140, 190, 110, 40, 15]
    }
  },
  {
    id: 'qr-2',
    statusLight: 'dim',
    sourceDb: 'AXP_1E_1048.1',
    timestamp: '2023-10-11 18:45:02',
    previewContent: 'Minor fluctuation recorded in lower band frequencies. Below threshold for standard trigger alert...',
    antecedents: {
      eventId: 'EVT-992-B',
      precursorEnergyErgs: '1.1 × 10^40',
      orbitalPhase: '0.119 π rad',
      telemetryStation: 'Deep Space Receiver 2',
      harmonicFrequenciesHz: [12.1, 24.2, 36.3],
      waveformPoints: [5, 8, 12, 19, 25, 22, 18, 14, 10, 8, 6, 5]
    }
  },
  {
    id: 'qr-3',
    statusLight: 'active',
    sourceDb: 'MGT_SGR_1806_20',
    timestamp: '2023-10-10 09:12:44',
    previewContent: 'Pre-burst harmonic resonance observed. Data aligns with theoretical model A-4 for magnetosphere reconnection.',
    antecedents: {
      eventId: 'EVT-104-X',
      precursorEnergyErgs: '8.9 × 10^43',
      orbitalPhase: '0.521 π rad',
      telemetryStation: 'Chandra X-Ray Substation',
      harmonicFrequenciesHz: [62.0, 124.0, 248.0],
      waveformPoints: [12, 18, 30, 55, 110, 160, 210, 175, 90, 45, 20]
    }
  },
  {
    id: 'qr-4',
    statusLight: 'active',
    sourceDb: 'SGR_0526_66_ARCHIVE',
    timestamp: '2023-09-28 14:02:11',
    previewContent: 'Giant flare precursor emission detected. High power pulse train across 0.5-10 keV band.',
    antecedents: {
      eventId: 'EVT-526-G',
      precursorEnergyErgs: '5.8 × 10^46',
      orbitalPhase: '0.910 π rad',
      telemetryStation: 'Swift Burst Alert Telescope',
      harmonicFrequenciesHz: [30.0, 60.0, 120.0, 240.0],
      waveformPoints: [20, 40, 90, 150, 230, 255, 210, 140, 70, 30]
    }
  }
];

export const INITIAL_UNIQUES_GROUPS: UniqueGroup[] = [
  {
    id: 'uniq-1',
    value: 'magnetar-flux-anomaly-alpha.gov',
    count: 42109,
    peakDailyRate: '2,450/day',
    distributionBars: [10, 15, 12, 8, 30, 60, 90, 100, 45, 25, 15, 10],
    timelineEvents: [
      {
        id: 'tle-1',
        time: '14:02',
        title: 'Burst_Gamma_Ray_DETECT',
        description: 'Intensity spike recorded crossing threshold omega. Cross-referenced with orbital station 4.',
        nodeType: 'highlight'
      },
      {
        id: 'tle-2',
        time: '11:45',
        title: 'Magnetic_Flux_Warning',
        description: 'Automated system triggered anomalous pattern recognition protocol.',
        nodeType: 'warning'
      },
      {
        id: 'tle-3',
        time: '08:12',
        title: 'Routine_Telemetry_Sync',
        description: 'Standard handshake completed. No anomalies prior to 11:45 event horizon.',
        nodeType: 'normal'
      }
    ]
  },
  {
    id: 'uniq-2',
    value: 'gamma-burst-repo.edu',
    count: 38552,
    peakDailyRate: '1,980/day',
    distributionBars: [20, 25, 30, 45, 50, 75, 80, 65, 40, 30, 20, 15],
    timelineEvents: [
      {
        id: 'tle-201',
        time: '18:22',
        title: 'Spectrum_Refinement_Complete',
        description: 'Calibrated baseline noise using Swift Observatory archival tables.',
        nodeType: 'normal'
      },
      {
        id: 'tle-202',
        time: '15:10',
        title: 'High_Energy_Cluster',
        description: 'Synchronized telemetry across 3 orbiting satellite nodes.',
        nodeType: 'highlight'
      }
    ]
  },
  {
    id: 'uniq-3',
    value: 'deep-space-telemetry.net',
    count: 15901,
    peakDailyRate: '890/day',
    distributionBars: [5, 10, 20, 25, 40, 50, 60, 55, 35, 20, 10, 5],
    timelineEvents: [
      {
        id: 'tle-301',
        time: '09:30',
        title: 'XRay_Pulsation_Lock',
        description: 'Phase correlation reached 99.4% confidence index.',
        nodeType: 'highlight'
      }
    ]
  },
  {
    id: 'uniq-4',
    value: 'neutron-star-metrics.org',
    count: 9440,
    peakDailyRate: '510/day',
    distributionBars: [15, 18, 22, 28, 35, 42, 48, 50, 38, 25, 18, 12],
    timelineEvents: [
      {
        id: 'tle-401',
        time: '04:15',
        title: 'Glitch_Precursor_Alert',
        description: 'Rotational frequency derivative derivative shift detected.',
        nodeType: 'warning'
      }
    ]
  },
  {
    id: 'uniq-5',
    value: 'xray-pulsar-node-7.mil',
    count: 8211,
    peakDailyRate: '440/day',
    distributionBars: [8, 12, 16, 22, 30, 40, 60, 70, 50, 30, 15, 10],
    timelineEvents: []
  },
  {
    id: 'uniq-6',
    value: 'unknown-signal-cluster.xyz',
    count: 4105,
    peakDailyRate: '210/day',
    distributionBars: [2, 5, 8, 14, 22, 35, 45, 55, 40, 20, 10, 4],
    timelineEvents: []
  },
  {
    id: 'uniq-7',
    value: 'stellar-wind-analyzer.int',
    count: 1200,
    peakDailyRate: '95/day',
    distributionBars: [1, 2, 4, 8, 12, 18, 24, 30, 20, 12, 6, 2],
    timelineEvents: []
  }
];

export const INITIAL_PROTOCOLS: ProtocolItem[] = [
  {
    id: 'prot-1',
    name: 'FFT_Harmonic_Decomposition',
    category: 'Spectral Analysis',
    description: 'Decomposes high-frequency X-ray light curves into Fourier modes to detect magnetospheric quasi-periodic oscillations (QPOs).',
    status: 'COMPLETED',
    lastRun: '12m ago',
    executionTimeMs: 420
  },
  {
    id: 'prot-2',
    name: 'Glitch_Detection_Derivative',
    category: 'Pulsar Timing',
    description: 'Monitors pulse arrival times (TOAs) for sudden step changes in angular velocity corresponding to crustal fractures.',
    status: 'IDLE',
    lastRun: '2h ago',
    executionTimeMs: 185
  },
  {
    id: 'prot-3',
    name: 'Cross_Satellite_Correlator',
    category: 'Telemetry Sync',
    description: 'Cross-correlates time-of-arrival delays between Swift, Fermi, and Chandra to pin-point spatial source coordinates.',
    status: 'RUNNING',
    lastRun: 'Just now',
    executionTimeMs: 890
  },
  {
    id: 'prot-4',
    name: 'Relativistic_Plasma_Simulator',
    category: 'Theoretical Modeling',
    description: 'Simulates magnetic field line reconnection in twisted magnetospheres at 10^15 Gauss.',
    status: 'IDLE',
    lastRun: '1d ago',
    executionTimeMs: 14200
  }
];

export const INITIAL_ARCHIVES: ArchiveFile[] = [
  {
    id: 'arc-1',
    name: 'SGR_1806_20_2004_Giant_Flare_Full_Telemetry.fits',
    size: '14.8 GB',
    date: '2023-11-15',
    telescope: 'RXTE / RHESSI Joint',
    downloads: 1420
  },
  {
    id: 'arc-2',
    name: 'AXP_1E_1048_Multi_Epoch_Timing_Logs.csv',
    size: '3.2 GB',
    date: '2023-10-02',
    telescope: 'XMM-Newton Observatory',
    downloads: 890
  },
  {
    id: 'arc-3',
    name: 'MagStar_Spectral_Energy_Distributions_V4.json',
    size: '850 MB',
    date: '2023-08-20',
    telescope: 'Chandra High-Resolution Camera',
    downloads: 2100
  }
];

export const ANGULAR_CODE_SNIPPETS: AngularComponentCode[] = [
  {
    title: 'AnalysisComponent (Angular 18 Standalone)',
    selector: 'app-analysis',
    tsCode: `import { Component, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MagnetarStateService } from '../services/magnetar-state.service';

@Component({
  selector: 'app-analysis',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './analysis.component.html',
  styleUrls: ['./analysis.component.css']
})
export class AnalysisComponent {
  private magnetarService = inject(MagnetarStateService);

  // Signal state from service
  readonly uniques = this.magnetarService.uniques;
  readonly selectedGroup = this.magnetarService.selectedUniqueGroup;
  
  // Local state
  groupByField = signal<'url' | 'ip' | 'signature' | 'magnitude'>('url');
  noteText = signal<string>('');

  saveNote(): void {
    if (this.selectedGroup()) {
      this.magnetarService.addNoteToGroup(this.selectedGroup()!.value, this.noteText());
      this.noteText.set('');
    }
  }
}`,
    htmlCode: `<div class="analysis-container border border-[#3a494b] bg-[#192122] rounded-lg p-6">
  <div class="header flex justify-between items-center mb-4">
    <h2 class="text-[#74f5ff] font-bold text-xl">Uniques & Frequencies</h2>
    <select [ngModel]="groupByField()" (ngModelChange)="groupByField.set($event)"
            class="bg-[#080f10] text-[#00dbe7] border border-[#3a494b] px-3 py-1.5 rounded">
      <option value="url">Source_URL</option>
      <option value="ip">Origin_IP</option>
      <option value="signature">Spectral_Signature</option>
    </select>
  </div>

  <div class="grid grid-cols-3 gap-6">
    <div class="col-span-1 bg-[#080f10] p-4 rounded border border-[#3a494b]">
      <div *for="let item of uniques()" 
           (click)="magnetarService.selectUniqueGroup(item)"
           class="p-2 cursor-pointer hover:bg-[#00dbe7]/10 flex justify-between">
        <span class="text-[#00dbe7] truncate">{{ item.value }}</span>
        <span class="text-white font-mono">{{ item.count | number }}</span>
      </div>
    </div>
  </div>
</div>`
  },
  {
    title: 'MagnetarStateService (Angular Reactive Injectable)',
    selector: 'Injectable Service',
    tsCode: `import { Injectable, signal, computed } from '@angular/core';
import { DatabaseSource, SavedFinding, QueryResult, UniqueGroup } from '../models/magnetar.models';

@Injectable({
  providedIn: 'root'
})
export class MagnetarStateService {
  // Reactive Signals for state management
  readonly databases = signal<DatabaseSource[]>(INITIAL_DATABASES);
  readonly queryResults = signal<QueryResult[]>(INITIAL_QUERY_RESULTS);
  readonly uniques = signal<UniqueGroup[]>(INITIAL_UNIQUES_GROUPS);
  
  readonly selectedUniqueGroup = signal<UniqueGroup | null>(INITIAL_UNIQUES_GROUPS[0]);
  readonly currentTab = signal<string>('analysis');

  readonly totalUniqueCount = computed(() => {
    return this.uniques().reduce((acc, curr) => acc + curr.count, 0);
  });

  selectUniqueGroup(group: UniqueGroup): void {
    this.selectedUniqueGroup.set(group);
  }

  addSavedFinding(finding: SavedFinding): void {
    this.savedFindings.update(items => [finding, ...items]);
  }
}`,
    htmlCode: `// Standalone Injectable Service - No HTML template required.`
  }
];
