import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationTab } from '../../types';

@Component({
  selector: 'app-side-nav-bar',
  standalone: true,
  imports: [CommonModule],
  template: `
    <aside className="w-[280px] bg-[#151d1e] border-r border-[#3a494b] flex flex-col justify-between p-4 h-screen fixed left-0 top-0 z-30 select-none">
      <div className="space-y-6">
        <!-- App Title Header -->
        <div className="flex items-center gap-3 px-2 pt-2">
          <div className="w-10 h-10 rounded bg-[#00dbe7]/10 border border-[#00dbe7]/30 flex items-center justify-center text-[#00dbe7] font-mono font-bold text-[18px]">
            MF
          </div>
          <div>
            <h1 className="font-['Geist',sans-serif] text-[16px] font-semibold text-[#dce4e4] leading-tight">
              Magnetar Finder
            </h1>
            <p className="font-mono text-[11px] text-[#b9cacb] tracking-wide">
              Angular 19 Standalone
            </p>
          </div>
        </div>

        <!-- Action Button -->
        <button
          (click)="openNewAnalysis.emit()"
          className="w-full py-2.5 px-4 bg-[#00dbe7] text-[#002022] font-bold text-[12px] tracking-wider uppercase rounded hover:bg-[#74f5ff] transition-colors flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(0,219,231,0.2)] cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px]">add</span>
          New Observation
        </button>

        <!-- Navigation Tabs -->
        <nav className="space-y-1">
          @for (nav of navItems; track nav.id) {
            <button
              (click)="selectTab.emit(nav.id)"
              [ngClass]="{
                'bg-[#00dbe7]/10 text-[#00dbe7] border-l-2 border-[#00dbe7] font-semibold': currentTab === nav.id,
                'text-[#b9cacb] hover:bg-[#192122] hover:text-[#dce4e4]': currentTab !== nav.id
              }"
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded text-[13px] font-mono transition-all text-left cursor-pointer"
            >
              <span className="material-symbols-outlined text-[20px]">{{ nav.icon }}</span>
              {{ nav.label }}
            </button>
          }
        </nav>
      </div>

      <!-- Footer Info -->
      <div className="space-y-3 border-t border-[#3a494b] pt-4 px-2 font-mono text-[11px]">
        <button
          (click)="openAngularCode.emit()"
          className="w-full py-2 px-3 bg-[#192122] hover:bg-[#2e3637] border border-[#3a494b] text-[#74f5ff] rounded transition-colors flex items-center justify-center gap-2 cursor-pointer font-bold"
        >
          <span className="material-symbols-outlined text-[16px]">code</span>
          Inspect Angular Code
        </button>

        <div className="text-[#b9cacb] flex justify-between items-center">
          <span>Engine Status</span>
          <span className="text-[#00dbe7] font-bold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00dbe7] animate-ping"></span>
            ACTIVE
          </span>
        </div>
      </div>
    </aside>
  `
})
export class SideNavBarComponent {
  @Input({ required: true }) currentTab!: NavigationTab;
  @Output() selectTab = new EventEmitter<NavigationTab>();
  @Output() openNewAnalysis = new EventEmitter<void>();
  @Output() openAngularCode = new EventEmitter<void>();

  navItems: { id: NavigationTab; label: string; icon: string }[] = [
    { id: 'analysis', label: 'Analysis & Timelines', icon: 'analytics' },
    { id: 'exploration', label: 'Exploration & Signals', icon: 'explore' },
    { id: 'database', label: 'Telemetry Databases', icon: 'database' },
    { id: 'archives', label: 'FITS Archives', icon: 'folder_zip' },
    { id: 'protocols', label: 'Pipeline Protocols', icon: 'terminal' },
  ];
}
