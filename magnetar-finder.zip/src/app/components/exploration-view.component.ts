import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DatabaseSource, QueryResult } from '../../types';

@Component({
  selector: 'app-exploration-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div className="flex-1 mt-16 p-8 h-[calc(100vh-64px)] overflow-y-auto bg-[#0d1515] text-[#dce4e4]">
      <div className="max-w-6xl mx-auto space-y-6">
        <!-- Section Header -->
        <div className="flex justify-between items-end border-b border-[#3a494b] pb-4">
          <div>
            <h2 className="font-['Geist',sans-serif] text-[24px] font-semibold text-[#dce4e4]">
              Signal Exploration & Antecedents
            </h2>
            <p className="text-[14px] text-[#b9cacb]">
              Cross-correlate high-energy gamma ray bursts with X-ray pulsar precursors.
            </p>
          </div>

          <button
            (click)="connectDatabase.emit()"
            className="px-4 py-2 bg-[#2e3637] hover:bg-[#00dbe7] hover:text-[#002022] text-[#dce4e4] font-mono text-[12px] font-bold uppercase tracking-wider rounded border border-[#3a494b] transition-all flex items-center gap-2 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">add_link</span>
            Connect SQLite DB
          </button>
        </div>

        <!-- Database Selection Chips -->
        <div className="space-y-2">
          <label className="text-[11px] font-mono uppercase tracking-wider text-[#b9cacb]">
            Active Telemetry Sources
          </label>
          <div className="flex flex-wrap gap-3">
            @for (db of databases; track db.id) {
              <button
                (click)="toggleDatabase.emit(db.id)"
                [ngClass]="{
                  'bg-[#00dbe7]/15 border-[#00dbe7] text-[#00dbe7]': db.connected,
                  'bg-[#192122] border-[#3a494b] text-[#b9cacb] hover:border-[#b9cacb]': !db.connected
                }"
                className="px-3 py-1.5 rounded border text-[12px] font-mono transition-all flex items-center gap-2 cursor-pointer"
              >
                <span
                  [ngClass]="db.connected ? 'bg-[#00dbe7]' : 'bg-[#3a494b]'"
                  className="w-2 h-2 rounded-full"
                ></span>
                {{ db.name }}
                <span className="text-[10px] opacity-70">({{ db.records }})</span>
              </button>
            }
          </div>
        </div>

        <!-- Query Results List -->
        <div className="space-y-4 pt-4">
          <h3 className="font-mono text-[14px] font-bold text-[#dce4e4] uppercase tracking-wider flex items-center gap-2">
            <span className="material-symbols-outlined text-[#00dbe7] text-[18px]">list_alt</span>
            Recent Telemetry Query Outputs
          </h3>

          <div className="space-y-3">
            @for (res of queryResults; track res.id) {
              <div
                className="bg-[#192122] border border-[#3a494b] rounded-lg p-5 hover:border-[#00dbe7]/50 transition-colors flex flex-col md:flex-row gap-4 justify-between items-start md:items-center"
              >
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-3 text-[12px] font-mono text-[#b9cacb]">
                    <span className="text-[#00dbe7] font-bold">{{ res.sourceDb }}</span>
                    <span>•</span>
                    <span>{{ res.timestamp }}</span>
                    <span>•</span>
                    <span className="text-[#74f5ff]">Event: {{ res.antecedents.eventId }}</span>
                  </div>

                  <p className="font-mono text-[13px] text-[#dce4e4] leading-relaxed">
                    {{ res.previewContent }}
                  </p>
                </div>

                <div className="flex items-center gap-3 shrink-0 border-t md:border-t-0 border-[#3a494b] pt-3 md:pt-0 w-full md:w-auto justify-end">
                  <button
                    (click)="selectAntecedents.emit(res)"
                    className="px-3 py-1.5 bg-[#2e3637] hover:bg-[#00dbe7] hover:text-[#002022] text-[#00dbe7] font-mono font-bold text-[11px] uppercase tracking-wider rounded border border-[#3a494b] transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[16px]">show_chart</span>
                    View Antecedents
                  </button>

                  <button
                    (click)="saveResult.emit(res)"
                    [disabled]="res.saved"
                    [ngClass]="{
                      'bg-[#00dbe7] text-[#002022] font-bold': res.saved,
                      'bg-[#151d1e] text-[#dce4e4] hover:bg-[#2e3637]': !res.saved
                    }"
                    className="px-3 py-1.5 font-mono text-[11px] uppercase tracking-wider rounded border border-[#3a494b] transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-80"
                  >
                    <span className="material-symbols-outlined text-[16px]">
                      {{ res.saved ? 'check' : 'bookmark' }}
                    </span>
                    {{ res.saved ? 'Saved' : 'Save Finding' }}
                  </button>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class ExplorationViewComponent {
  @Input({ required: true }) databases!: DatabaseSource[];
  @Input({ required: true }) queryResults!: QueryResult[];

  @Output() toggleDatabase = new EventEmitter<string>();
  @Output() selectAntecedents = new EventEmitter<QueryResult>();
  @Output() saveResult = new EventEmitter<QueryResult>();
  @Output() connectDatabase = new EventEmitter<void>();
}
