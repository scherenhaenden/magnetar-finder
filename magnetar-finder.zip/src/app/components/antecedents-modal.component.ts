import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QueryResult } from '../../types';

@Component({
  selector: 'app-antecedents-modal',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if (result) {
      <div className="fixed inset-0 z-50 bg-[#080f10]/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
        <div className="bg-[#192122] border border-[#00dbe7] rounded-lg max-w-2xl w-full p-6 shadow-[0_0_25px_rgba(0,219,231,0.25)] flex flex-col gap-6 text-[#dce4e4]">
          <!-- Header -->
          <div className="flex justify-between items-center border-b border-[#3a494b] pb-4">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#00dbe7] font-mono">
                Antecedent Signal Analysis
              </span>
              <h3 className="font-mono text-[20px] font-bold text-[#74f5ff]">
                {{ result.antecedents.eventId }} — {{ result.sourceDb }}
              </h3>
            </div>
            <button
              (click)="close.emit()"
              className="text-[#b9cacb] hover:text-[#ffb4ab] transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[24px]">close</span>
            </button>
          </div>

          <!-- Metrics Grid -->
          <div className="grid grid-cols-3 gap-4 bg-[#080f10] p-4 rounded border border-[#3a494b] font-mono text-[12px]">
            <div>
              <div className="text-[10px] text-[#b9cacb] uppercase">Precursor Energy</div>
              <div className="text-[#00dbe7] font-bold text-[14px]">{{ result.antecedents.precursorEnergyErgs }} ergs</div>
            </div>
            <div>
              <div className="text-[10px] text-[#b9cacb] uppercase">Orbital Phase</div>
              <div className="text-[#dce4e4] font-bold text-[14px]">{{ result.antecedents.orbitalPhase }}</div>
            </div>
            <div>
              <div className="text-[10px] text-[#b9cacb] uppercase">Telemetry Station</div>
              <div className="text-[#dce4e4] font-bold text-[13px] truncate">{{ result.antecedents.telemetryStation }}</div>
            </div>
          </div>

          <!-- Waveform Pulse Visualization -->
          <div className="border border-[#3a494b] rounded p-4 bg-[#0d1515]">
            <div className="text-[11px] font-mono text-[#b9cacb] mb-2 flex justify-between">
              <span>Precursor Pulse Train Waveform</span>
              <span>Harmonics: {{ result.antecedents.harmonicFrequenciesHz.join(', ') }} Hz</span>
            </div>

            <div className="flex items-end gap-1 h-24 w-full pt-4">
              @for (val of result.antecedents.waveformPoints; track $index) {
                <div
                  [style.height.%]="(val / 255) * 100"
                  className="flex-1 bg-[#00dbe7] hover:bg-[#74f5ff] transition-all rounded-t shadow-[0_0_6px_rgba(0,219,231,0.4)]"
                  [attr.title]="'Point ' + ($index + 1) + ': ' + val + ' keV'"
                ></div>
              }
            </div>
          </div>

          <!-- Content Snippet -->
          <div className="bg-[#151d1e] p-3 rounded border border-[#3a494b] text-[13px] font-mono text-[#b9cacb]">
            {{ result.previewContent }}
          </div>

          <div className="flex justify-end gap-3 border-t border-[#3a494b] pt-4">
            <button
              (click)="close.emit()"
              className="px-5 py-2 bg-[#00dbe7] text-[#002022] font-bold text-[11px] uppercase tracking-wider rounded hover:bg-[#74f5ff] transition-colors cursor-pointer"
            >
              Dismiss Antecedents
            </button>
          </div>
        </div>
      </div>
    }
  `
})
export class AntecedentsModalComponent {
  @Input() result: QueryResult | null = null;
  @Output() close = new EventEmitter<void>();
}
