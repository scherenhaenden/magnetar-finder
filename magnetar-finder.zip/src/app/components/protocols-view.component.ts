import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProtocolItem } from '../../types';

@Component({
  selector: 'app-protocols-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div className="flex-1 mt-16 p-8 h-[calc(100vh-64px)] overflow-y-auto bg-[#0d1515] text-[#dce4e4]">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="border-b border-[#3a494b] pb-4">
          <h2 className="font-['Geist',sans-serif] text-[24px] font-semibold text-[#dce4e4]">
            Automated Pipeline Protocols
          </h2>
          <p className="text-[14px] text-[#b9cacb]">
            High-frequency FFT harmonic decomposition, pulsar timing derivative monitors, and plasma simulations.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <!-- Protocol Cards -->
          <div className="space-y-4">
            @for (p of activeProtocols; track p.id) {
              <div
                className="bg-[#192122] border border-[#3a494b] rounded-lg p-5 hover:border-[#00dbe7]/50 transition-colors flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[#00dbe7] font-mono">
                      {{ p.category }}
                    </span>
                    <span
                      [ngClass]="{
                        'bg-[#00f2ff]/20 text-[#74f5ff] animate-pulse': p.status === 'RUNNING',
                        'bg-[#3a4a5f] text-[#a9bad3]': p.status === 'COMPLETED',
                        'bg-[#333b3b] text-[#b9cacb]': p.status === 'IDLE'
                      }"
                      className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase"
                    >
                      {{ p.status }}
                    </span>
                  </div>
                  <h3 className="font-mono text-[16px] font-bold text-[#dce4e4] mb-2">
                    {{ p.name }}
                  </h3>
                  <p className="text-[13px] text-[#b9cacb] mb-4">{{ p.description }}</p>
                </div>

                <div className="flex items-center justify-between border-t border-[#3a494b] pt-3">
                  <span className="text-[11px] font-mono text-[#b9cacb]">
                    Last Run: {{ p.lastRun }}
                  </span>
                  <button
                    (click)="runProtocol(p.id, p.name)"
                    [disabled]="runningId === p.id"
                    className="px-4 py-1.5 bg-[#00dbe7] text-[#002022] font-bold text-[11px] uppercase tracking-wider rounded hover:bg-[#74f5ff] transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <span className="material-symbols-outlined text-[16px]">play_arrow</span>
                    Run Protocol
                  </button>
                </div>
              </div>
            }
          </div>

          <!-- Live CLI Output Console -->
          <div className="bg-[#080f10] border border-[#3a494b] rounded-lg p-4 flex flex-col h-[520px]">
            <div className="flex items-center justify-between border-b border-[#3a494b] pb-3 mb-3 shrink-0">
              <div className="flex items-center gap-2 text-[12px] font-mono font-bold text-[#00dbe7]">
                <span className="material-symbols-outlined text-[16px]">terminal</span>
                TELEMETRY_CLI_OUTPUT
              </div>
              <button
                (click)="consoleLogs = []"
                className="text-[10px] font-mono text-[#b9cacb] hover:text-[#dce4e4] uppercase cursor-pointer"
              >
                Clear Console
              </button>
            </div>

            <div className="flex-1 overflow-y-auto font-mono text-[12px] text-[#74f5ff] space-y-2 p-2 bg-[#0d1515] rounded border border-[#3a494b]/50">
              @for (log of consoleLogs; track $index) {
                <div className="leading-relaxed">
                  <span className="text-[#b9cacb] select-none">&gt; </span>
                  {{ log }}
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ProtocolsViewComponent implements OnInit {
  @Input({ required: true }) protocols!: ProtocolItem[];

  activeProtocols: ProtocolItem[] = [];
  consoleLogs: string[] = [
    '[SYSTEM] Magnetar Finder Automation Engine v4.2 initialized.',
    '[FFT] QPO Peak detected at 24.5 Hz in sector 4 lightcurve.',
    '[SYNC] Cross-satellite time-of-arrival delay: +1.284 ms.',
    '[READY] All execution protocols armed.'
  ];
  runningId: string | null = null;

  ngOnInit() {
    this.activeProtocols = [...this.protocols];
  }

  runProtocol(id: string, name: string) {
    this.runningId = id;
    this.consoleLogs.push(`[TRIGGER] Initiating ${name}...`);

    setTimeout(() => {
      this.activeProtocols = this.activeProtocols.map(p =>
        p.id === id ? { ...p, status: 'RUNNING', lastRun: 'Running...' } : p
      );
      this.consoleLogs.push(`[EXEC] ${name}: Computing fast Fourier transforms across 1,402,883 telemetry records...`);
    }, 400);

    setTimeout(() => {
      this.activeProtocols = this.activeProtocols.map(p =>
        p.id === id ? { ...p, status: 'COMPLETED', lastRun: 'Just now' } : p
      );
      this.consoleLogs.push(`[SUCCESS] ${name} completed in 420ms. Spectral harmonics stored in cache.`);
      this.runningId = null;
    }, 1200);
  }
}
