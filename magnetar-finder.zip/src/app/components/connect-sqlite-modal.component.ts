import { Component, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-connect-sqlite-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div className="fixed inset-0 z-50 bg-[#080f10]/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-[#192122] border border-[#00dbe7] rounded-lg max-w-md w-full p-6 shadow-[0_0_25px_rgba(0,219,231,0.25)] flex flex-col gap-5 text-[#dce4e4]">
        <div className="flex justify-between items-center border-b border-[#3a494b] pb-3">
          <h3 className="font-mono text-[18px] font-bold text-[#74f5ff] flex items-center gap-2">
            <span className="material-symbols-outlined text-[20px]">add_link</span>
            Connect SQLite Database
          </h3>
          <button (click)="close.emit()" className="text-[#b9cacb] hover:text-[#ffb4ab] cursor-pointer">
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <form (ngSubmit)="handleSubmit()" className="space-y-4 font-mono text-[12px]">
          <div>
            <label className="text-[#b9cacb] uppercase block mb-1">Database Label / Name</label>
            <input
              type="text"
              [(ngModel)]="dbName"
              name="dbName"
              className="w-full bg-[#080f10] border border-[#3a494b] rounded p-2 text-[#dce4e4] focus:border-[#00dbe7] outline-none"
            />
          </div>

          <div>
            <label className="text-[#b9cacb] uppercase block mb-1">File Path or SQLite Attachment URI</label>
            <input
              type="text"
              [(ngModel)]="dbPath"
              name="dbPath"
              className="w-full bg-[#080f10] border border-[#3a494b] rounded p-2 text-[#dce4e4] focus:border-[#00dbe7] outline-none"
            />
          </div>

          <div className="border border-dashed border-[#3a494b] rounded p-6 text-center text-[#b9cacb] hover:border-[#00dbe7] cursor-pointer transition-colors bg-[#080f10]">
            <span className="material-symbols-outlined text-[32px] text-[#00dbe7] mb-1">
              upload_file
            </span>
            <div className="text-[12px]">Drop .sqlite, .db, or .fits file here</div>
            <div className="text-[10px] text-[#b9cacb]/60">Supports SQLite v3 WASM & Virtual Tables</div>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-[#3a494b]">
            <button
              type="button"
              (click)="close.emit()"
              className="px-4 py-2 text-[#b9cacb] hover:text-[#dce4e4] font-bold uppercase tracking-wider cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#00dbe7] text-[#002022] font-bold uppercase tracking-wider rounded hover:bg-[#74f5ff] transition-colors cursor-pointer"
            >
              Connect Database
            </button>
          </div>
        </form>
      </div>
    </div>
  `
})
export class ConnectSqliteModalComponent {
  @Output() close = new EventEmitter<void>();
  @Output() connect = new EventEmitter<{ dbName: string; dbSize: string }>();

  dbName = 'SGR_0526_66.sqlite';
  dbPath = '/mnt/data/SGR_0526_66.sqlite';

  handleSubmit() {
    if (this.dbName.trim()) {
      this.connect.emit({
        dbName: this.dbName.trim(),
        dbSize: '3.1 GB'
      });
      this.close.emit();
    }
  }
}
