import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DatabaseSource, SavedFinding } from '../../types';

@Component({
  selector: 'app-database-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div className="flex-1 mt-16 p-8 h-[calc(100vh-64px)] overflow-y-auto bg-[#0d1515] text-[#dce4e4]">
      <div className="max-w-6xl mx-auto space-y-8">
        <!-- Section Header -->
        <div className="flex justify-between items-end border-b border-[#3a494b] pb-4">
          <div>
            <h2 className="font-['Geist',sans-serif] text-[24px] font-semibold text-[#dce4e4]">
              Connected Telemetry Databases
            </h2>
            <p className="text-[14px] text-[#b9cacb]">
              Local SQLite mirrors, virtual FITS arrays, and indexed magnetar pulsar records.
            </p>
          </div>

          <button
            (click)="connectSqlite.emit()"
            className="px-4 py-2 bg-[#00dbe7] text-[#002022] font-mono text-[12px] font-bold uppercase tracking-wider rounded hover:bg-[#74f5ff] transition-all flex items-center gap-2 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">add_link</span>
            Connect SQLite Database
          </button>
        </div>

        <!-- Databases Table Grid -->
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          @for (db of databases; track db.id) {
            <div
              className="bg-[#192122] border border-[#3a494b] rounded-lg p-5 flex flex-col justify-between space-y-4 hover:border-[#00dbe7]/50 transition-colors"
            >
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-[10px] font-mono font-bold uppercase text-[#00dbe7] tracking-wider">
                    {{ db.status }}
                  </span>
                  <span className="text-[11px] font-mono text-[#b9cacb]">
                    Size: {{ db.size }}
                  </span>
                </div>

                <h3 className="font-mono text-[16px] font-bold text-[#dce4e4] mb-1">
                  {{ db.name }}
                </h3>

                <div className="text-[12px] font-mono text-[#b9cacb] space-y-1">
                  <div>Indexed Records: {{ db.records }}</div>
                  <div>Last Sync: {{ db.lastSync }}</div>
                </div>
              </div>

              <div className="flex justify-between items-center border-t border-[#3a494b] pt-3">
                <span className="text-[11px] font-mono text-[#b9cacb]">
                  Status: {{ db.connected ? 'Attached' : 'Detached' }}
                </span>
                <button
                  (click)="connectSqlite.emit()"
                  className="px-3 py-1 bg-[#2e3637] hover:bg-[#00dbe7] hover:text-[#002022] text-[#dce4e4] font-mono text-[11px] uppercase tracking-wider rounded transition-colors cursor-pointer"
                >
                  Configure
                </button>
              </div>
            </div>
          }
        </div>

        <!-- Saved Findings & Bookmarks Section -->
        <div className="space-y-4 pt-4 border-t border-[#3a494b]">
          <h3 className="font-mono text-[16px] font-bold text-[#dce4e4] uppercase tracking-wider flex items-center gap-2">
            <span className="material-symbols-outlined text-[#00dbe7] text-[20px]">bookmarks</span>
            Saved Research Findings & Bookmarks
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            @for (finding of savedFindings; track finding.id) {
              <div
                className="bg-[#192122] border border-[#3a494b] rounded p-4 flex flex-col justify-between space-y-3"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-mono text-[#00dbe7] font-bold uppercase">
                      {{ finding.type }}
                    </span>
                    <h4 className="font-mono text-[15px] font-bold text-[#74f5ff]">
                      {{ finding.eventId }}
                    </h4>
                  </div>

                  <button
                    (click)="toggleBookmark.emit(finding.id)"
                    className="text-[#00dbe7] hover:text-[#74f5ff] cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[20px]">
                      {{ finding.bookmarked ? 'bookmark' : 'bookmark_border' }}
                    </span>
                  </button>
                </div>

                <p className="text-[12px] font-mono text-[#b9cacb] leading-relaxed">
                  {{ finding.customNote }}
                </p>

                <div className="text-[11px] font-mono text-[#00dbe7] font-bold">
                  Energy Magnitude: {{ finding.magnitude }}
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class DatabaseViewComponent {
  @Input({ required: true }) databases!: DatabaseSource[];
  @Input({ required: true }) savedFindings!: SavedFinding[];

  @Output() toggleBookmark = new EventEmitter<string>();
  @Output() connectSqlite = new EventEmitter<void>();
}
