import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UniqueGroup } from '../../types';

@Component({
  selector: 'app-analysis-view',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div className="flex-1 mt-16 p-8 h-[calc(100vh-64px)] overflow-y-auto bg-[#0d1515] text-[#dce4e4]">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Column 1: Uniques Groups List -->
        <div className="lg:col-span-1 space-y-4">
          <div className="border-b border-[#3a494b] pb-3">
            <h2 className="font-['Geist',sans-serif] text-[20px] font-semibold text-[#dce4e4]">
              Uniques Groups
            </h2>
            <p className="text-[12px] text-[#b9cacb]">
              Grouped astrophysical candidate sources by spin period derivative.
            </p>
          </div>

          <div className="space-y-3">
            @for (group of uniquesGroups; track group.value) {
              <div
                (click)="selectGroup.emit(group)"
                [ngClass]="{
                  'border-[#00dbe7] bg-[#192122] shadow-[0_0_15px_rgba(0,219,231,0.15)]': selectedGroup.value === group.value,
                  'border-[#3a494b] bg-[#151d1e] hover:border-[#00dbe7]/50': selectedGroup.value !== group.value
                }"
                className="border rounded-lg p-4 transition-all cursor-pointer space-y-2"
              >
                <div className="flex justify-between items-center">
                  <span className="font-mono text-[14px] font-bold text-[#74f5ff]">
                    {{ group.value }}
                  </span>
                  <span className="px-2 py-0.5 bg-[#2e3637] text-[#00dbe7] rounded font-mono text-[10px] font-bold">
                    {{ group.count }} Sources
                  </span>
                </div>

                <p className="text-[12px] text-[#b9cacb] font-mono leading-snug">
                  {{ group.label }}
                </p>

                <div className="flex justify-between items-center text-[11px] font-mono text-[#b9cacb] pt-2 border-t border-[#3a494b]/50">
                  <span>Confidence: {{ group.confidence }}</span>
                  <span className="text-[#00dbe7]">{{ group.timelineEvents.length }} Events</span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Column 2 & 3: Selected Group Detail & Timeline -->
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#192122] border border-[#3a494b] rounded-lg p-6 space-y-6">
            <div className="flex justify-between items-start border-b border-[#3a494b] pb-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#00dbe7] font-mono">
                  Active Analysis Subject
                </span>
                <h3 className="font-mono text-[22px] font-bold text-[#74f5ff]">
                  {{ selectedGroup.value }} — {{ selectedGroup.label }}
                </h3>
              </div>
              <span className="px-3 py-1 bg-[#00dbe7]/20 border border-[#00dbe7] text-[#00dbe7] rounded font-mono text-[11px] font-bold">
                Confidence {{ selectedGroup.confidence }}
              </span>
            </div>

            <!-- Timeline Events -->
            <div className="space-y-4">
              <h4 className="font-mono text-[13px] font-bold text-[#dce4e4] uppercase tracking-wider flex items-center gap-2">
                <span className="material-symbols-outlined text-[#00dbe7] text-[18px]">timeline</span>
                Observation Timeline Logs
              </h4>

              <div className="relative border-l-2 border-[#3a494b] ml-3 pl-6 space-y-6">
                @for (evt of selectedGroup.timelineEvents; track evt.id) {
                  <div className="relative">
                    <span
                      [ngClass]="{
                        'bg-[#00dbe7] text-[#002022]': evt.nodeType === 'signal',
                        'bg-[#ffb4ab] text-[#690005]': evt.nodeType === 'burst',
                        'bg-[#74f5ff] text-[#002022]': evt.nodeType === 'highlight'
                      }"
                      className="absolute -left-[31px] top-0 w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px]"
                    >
                      •
                    </span>

                    <div className="font-mono text-[11px] text-[#00dbe7] font-bold">
                      {{ evt.time }}
                    </div>
                    <div className="font-mono text-[14px] font-bold text-[#dce4e4] mt-0.5">
                      {{ evt.title }}
                    </div>
                    <p className="text-[12px] text-[#b9cacb] mt-1 font-mono leading-relaxed">
                      {{ evt.description }}
                    </p>
                  </div>
                }
              </div>
            </div>

            <!-- Add Researcher Note Form -->
            <div className="border-t border-[#3a494b] pt-4 space-y-3">
              <label className="text-[11px] font-mono uppercase tracking-wider text-[#b9cacb] block">
                Add Researcher Log Entry
              </label>
              <div className="flex gap-3">
                <input
                  type="text"
                  [(ngModel)]="noteText"
                  (keyup.enter)="handleAddNote()"
                  placeholder="Annotate timing residual anomalous behavior..."
                  className="flex-1 bg-[#0d1515] border border-[#3a494b] rounded py-2 px-3 font-mono text-[12px] text-[#dce4e4] focus:border-[#00dbe7] outline-none"
                />
                <button
                  (click)="handleAddNote()"
                  className="px-4 py-2 bg-[#00dbe7] text-[#002022] font-mono font-bold text-[11px] uppercase tracking-wider rounded hover:bg-[#74f5ff] transition-colors cursor-pointer shrink-0"
                >
                  Post Note
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  `
})
export class AnalysisViewComponent {
  @Input({ required: true }) uniquesGroups!: UniqueGroup[];
  @Input({ required: true }) selectedGroup!: UniqueGroup;

  @Output() selectGroup = new EventEmitter<UniqueGroup>();
  @Output() saveNote = new EventEmitter<{ groupValue: string; noteText: string }>();

  noteText = '';

  handleAddNote() {
    if (this.noteText.trim()) {
      this.saveNote.emit({
        groupValue: this.selectedGroup.value,
        noteText: this.noteText.trim()
      });
      this.noteText = '';
    }
  }
}
