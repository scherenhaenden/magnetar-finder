import { Component, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-new-analysis-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div className="fixed inset-0 z-50 bg-[#080f10]/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-[#192122] border border-[#00dbe7] rounded-lg max-w-lg w-full p-6 shadow-[0_0_25px_rgba(0,219,231,0.25)] flex flex-col gap-5 text-[#dce4e4]">
        <div className="flex justify-between items-center border-b border-[#3a494b] pb-3">
          <h3 className="font-mono text-[18px] font-bold text-[#74f5ff] flex items-center gap-2">
            <span className="material-symbols-outlined text-[20px]">add</span>
            New Observation Analysis Pipeline
          </h3>
          <button (click)="close.emit()" className="text-[#b9cacb] hover:text-[#ffb4ab] cursor-pointer">
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <form (ngSubmit)="handleSubmit()" className="space-y-4 font-mono text-[12px]">
          <div>
            <label className="text-[#b9cacb] uppercase block mb-1">Pipeline Title</label>
            <input
              type="text"
              [(ngModel)]="pipelineTitle"
              name="pipelineTitle"
              className="w-full bg-[#080f10] border border-[#3a494b] rounded p-2 text-[#dce4e4] focus:border-[#00dbe7] outline-none"
            />
          </div>

          <div>
            <label className="text-[#b9cacb] uppercase block mb-1">Primary Observatory Stream</label>
            <select
              [(ngModel)]="telescopeSource"
              name="telescopeSource"
              className="w-full bg-[#080f10] border border-[#3a494b] rounded p-2 text-[#00dbe7] focus:border-[#00dbe7] outline-none"
            >
              <option value="Swift / BAT Joint Feed">Swift / BAT Joint Feed</option>
              <option value="Fermi Gamma-ray Burst Monitor">Fermi Gamma-ray Burst Monitor</option>
              <option value="Chandra High Resolution Camera">Chandra High Resolution Camera</option>
              <option value="RXTE Proportional Counter Array">RXTE Proportional Counter Array</option>
            </select>
          </div>

          <div>
            <label className="text-[#b9cacb] uppercase block mb-1">Energy Band Filter</label>
            <input
              type="text"
              [(ngModel)]="energyBand"
              name="energyBand"
              className="w-full bg-[#080f10] border border-[#3a494b] rounded p-2 text-[#dce4e4] focus:border-[#00dbe7] outline-none"
            />
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-[#3a494b]">
            <button
              type="button"
              (click)="close.emit()"
              className="px-4 py-2 text-[#b9cacb] hover:text-[#dce4e4] font-bold uppercase tracking-wider cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#00dbe7] text-[#002022] font-bold uppercase tracking-wider rounded hover:bg-[#74f5ff] transition-colors cursor-pointer"
            >
              Launch Pipeline
            </button>
          </div>
        </form>
      </div>
    </div>
  `
})
export class NewAnalysisModalComponent {
  @Output() close = new EventEmitter<void>();
  @Output() launch = new EventEmitter<string>();

  pipelineTitle = 'SGR 1806-20 Spectral Flare Correlator';
  telescopeSource = 'Swift / BAT Joint Feed';
  energyBand = '0.5 - 100 keV';

  handleSubmit() {
    if (this.pipelineTitle.trim()) {
      this.launch.emit(this.pipelineTitle.trim());
      this.close.emit();
    }
  }
}
