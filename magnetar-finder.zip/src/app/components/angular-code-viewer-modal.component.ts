import { Component, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ANGULAR_CODE_SNIPPETS } from '../../data/mockData';

@Component({
  selector: 'app-angular-code-viewer-modal',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div className="fixed inset-0 z-50 bg-[#080f10]/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-[#192122] border border-[#00dbe7] rounded-lg max-w-4xl w-full h-[85vh] p-6 shadow-[0_0_30px_rgba(0,219,231,0.3)] flex flex-col gap-4 text-[#dce4e4]">
        <!-- Header -->
        <div className="flex justify-between items-center border-b border-[#3a494b] pb-3 shrink-0">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#00dbe7] font-mono">
              Angular 19 Native Component Inspector
            </span>
            <h3 className="font-mono text-[20px] font-bold text-[#74f5ff]">
              {{ snippets[activeSnippetIdx].title }}
            </h3>
          </div>
          <button (click)="close.emit()" className="text-[#b9cacb] hover:text-[#ffb4ab] cursor-pointer">
            <span className="material-symbols-outlined text-[24px]">close</span>
          </button>
        </div>

        <!-- Snippet Selection Tabs -->
        <div className="flex justify-between items-center gap-4 shrink-0 font-mono text-[12px]">
          <div className="flex gap-2">
            @for (snip of snippets; track $index) {
              <button
                (click)="activeSnippetIdx = $index"
                [ngClass]="{
                  'bg-[#00dbe7]/15 text-[#74f5ff] border border-[#00dbe7]/50 font-bold': activeSnippetIdx === $index,
                  'text-[#b9cacb] hover:bg-[#2e3637]': activeSnippetIdx !== $index
                }"
                className="px-3 py-1.5 rounded transition-all cursor-pointer"
              >
                {{ snip.selector }}
              </button>
            }
          </div>

          <div className="flex gap-1 bg-[#080f10] p-1 rounded border border-[#3a494b]">
            <button
              (click)="codeType = 'ts'"
              [ngClass]="{
                'bg-[#00dbe7] text-[#002022]': codeType === 'ts',
                'text-[#b9cacb]': codeType !== 'ts'
              }"
              className="px-3 py-1 rounded cursor-pointer font-bold"
            >
              TypeScript (.ts)
            </button>
            <button
              (click)="codeType = 'html'"
              [ngClass]="{
                'bg-[#00dbe7] text-[#002022]': codeType === 'html',
                'text-[#b9cacb]': codeType !== 'html'
              }"
              className="px-3 py-1 rounded cursor-pointer font-bold"
            >
              HTML (.html)
            </button>
          </div>
        </div>

        <!-- Code Output Canvas -->
        <div className="flex-1 bg-[#080f10] border border-[#3a494b] rounded p-4 font-mono text-[12px] text-[#74f5ff] overflow-y-auto relative">
          <button
            (click)="copyCode()"
            className="absolute top-3 right-3 px-3 py-1 bg-[#2e3637] hover:bg-[#00dbe7] hover:text-[#002022] text-[#dce4e4] font-bold text-[10px] uppercase rounded transition-colors flex items-center gap-1 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[14px]">
              {{ copied ? 'check' : 'content_copy' }}
            </span>
            {{ copied ? 'Copied!' : 'Copy Code' }}
          </button>

          <pre className="whitespace-pre-wrap leading-relaxed">{{ displayedCode }}</pre>
        </div>

        <!-- Footer info -->
        <div className="flex justify-between items-center text-[11px] font-mono text-[#b9cacb] pt-2 border-t border-[#3a494b] shrink-0">
          <div>Architecture: Angular Signals + Injectable Reactive Service + Standalone Component</div>
          <button
            (click)="close.emit()"
            className="px-4 py-1.5 bg-[#00dbe7] text-[#002022] font-bold uppercase rounded hover:bg-[#74f5ff] transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  `
})
export class AngularCodeViewerModalComponent {
  @Output() close = new EventEmitter<void>();

  snippets = ANGULAR_CODE_SNIPPETS;
  activeSnippetIdx = 0;
  codeType: 'ts' | 'html' = 'ts';
  copied = false;

  get displayedCode(): string {
    const snip = this.snippets[this.activeSnippetIdx];
    return this.codeType === 'ts' ? snip.tsCode : snip.htmlCode;
  }

  copyCode() {
    navigator.clipboard.writeText(this.displayedCode);
    this.copied = true;
    setTimeout(() => (this.copied = false), 2000);
  }
}
