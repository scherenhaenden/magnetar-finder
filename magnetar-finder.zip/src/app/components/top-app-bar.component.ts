import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-top-app-bar',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <header className="h-16 bg-[#151d1e] border-b border-[#3a494b] flex items-center justify-between px-6 fixed top-0 right-0 left-[280px] z-20 backdrop-blur-md">
      <!-- Search Bar -->
      <div className="relative w-96">
        <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-[#b9cacb] text-[18px]">
          search
        </span>
        <input
          type="text"
          [ngModel]="searchQuery"
          (ngModelChange)="searchChange.emit($event)"
          (keyup.enter)="executeQuery.emit()"
          placeholder="Query gamma burst spectra, spin derivatives..."
          className="w-full bg-[#0d1515] border border-[#3a494b] rounded py-1.5 pl-9 pr-3 font-mono text-[13px] text-[#dce4e4] placeholder-[#b9cacb]/50 focus:border-[#00dbe7] focus:outline-none"
        />
      </div>

      <!-- Action Sub-Tabs & Execute -->
      <div className="flex items-center gap-4">
        <div className="flex bg-[#0d1515] p-1 rounded border border-[#3a494b] font-mono text-[12px]">
          @for (sub of subTabs; track sub) {
            <button
              (click)="selectSubTab.emit(sub)"
              [ngClass]="{
                'bg-[#00dbe7] text-[#002022] font-bold': activeSubTab === sub,
                'text-[#b9cacb] hover:text-[#dce4e4]': activeSubTab !== sub
              }"
              className="px-3 py-1 rounded transition-colors cursor-pointer"
            >
              {{ sub }}
            </button>
          }
        </div>

        <button
          (click)="executeQuery.emit()"
          [disabled]="isExecuting"
          className="px-4 py-1.5 bg-[#00dbe7] text-[#002022] font-mono font-bold text-[12px] uppercase tracking-wider rounded hover:bg-[#74f5ff] transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
        >
          <span className="material-symbols-outlined text-[16px]">
            {{ isExecuting ? 'sync' : 'play_arrow' }}
          </span>
          {{ isExecuting ? 'Querying...' : 'Run Query' }}
        </button>
      </div>
    </header>
  `
})
export class TopAppBarComponent {
  @Input({ required: true }) searchQuery!: string;
  @Input({ required: true }) activeSubTab!: string;
  @Input() isExecuting = false;

  @Output() searchChange = new EventEmitter<string>();
  @Output() selectSubTab = new EventEmitter<string>();
  @Output() executeQuery = new EventEmitter<void>();

  subTabs = ['Overview', 'History', 'Harmonics'];
}
