import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ArchiveFile } from '../../types';

@Component({
  selector: 'app-archives-view',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div className="flex-1 mt-16 p-8 h-[calc(100vh-64px)] overflow-y-auto bg-[#0d1515] text-[#dce4e4]">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex justify-between items-end border-b border-[#3a494b] pb-4">
          <div>
            <h2 className="font-['Geist',sans-serif] text-[24px] font-semibold text-[#dce4e4]">
              Deep Space Telemetry Archives
            </h2>
            <p className="text-[14px] text-[#b9cacb]">
              Historical observational datasets, FITS files, and joint multi-epoch timing logs.
            </p>
          </div>

          <div className="relative w-72">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-[#b9cacb] text-[18px]">
              search
            </span>
            <input
              type="text"
              [(ngModel)]="filter"
              placeholder="Search telescope archives..."
              className="w-full bg-[#151d1e] border border-[#3a494b] rounded py-1.5 pl-9 pr-3 font-mono text-[13px] text-[#dce4e4] placeholder-[#b9cacb]/50 focus:border-[#00dbe7] outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          @for (archive of filteredArchives; track archive.id) {
            <div
              className="bg-[#192122] border border-[#3a494b] rounded-lg p-5 hover:border-[#00dbe7]/50 transition-colors flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-2 text-[#00dbe7] font-mono text-[12px] font-bold mb-2">
                  <span className="material-symbols-outlined text-[18px]">folder_zip</span>
                  {{ archive.size }}
                </div>
                <h3 className="font-semibold text-[15px] text-[#dce4e4] mb-2 break-all">
                  {{ archive.name }}
                </h3>
                <div className="text-[12px] text-[#b9cacb] space-y-1 font-mono">
                  <div>Telescope: {{ archive.telescope }}</div>
                  <div>Catalog Date: {{ archive.date }}</div>
                  <div>Total Downloads: {{ archive.downloads | number }}</div>
                </div>
              </div>

              <button
                (click)="downloadArchive(archive.name)"
                className="mt-6 w-full py-2 bg-[#2e3637] hover:bg-[#00dbe7] hover:text-[#002022] text-[#dce4e4] font-bold text-[11px] uppercase tracking-wider rounded border border-[#3a494b] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px]">download</span>
                Download FITS / Archive
              </button>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class ArchivesViewComponent {
  @Input({ required: true }) archives!: ArchiveFile[];

  filter = '';

  get filteredArchives(): ArchiveFile[] {
    if (!this.filter.trim()) return this.archives;
    const q = this.filter.toLowerCase();
    return this.archives.filter(a =>
      a.name.toLowerCase().includes(q) ||
      a.telescope.toLowerCase().includes(q)
    );
  }

  downloadArchive(name: string) {
    alert(`Downloading dataset ${name}...`);
  }
}
